/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

/**
 *
 * @author ester maria
 */
public class Professeur {
    
    int matriculeProf;
   String nomProf, prenomProf,groupeProf,naissanceProf,telephoneProf,adresseProf,emailProf;

    public Professeur(int matriculeProf, String nomProf, String prenomProf, String groupeProf, String naissanceProf, String telephoneProf, String adresseProf, String emailProf) {
        this.matriculeProf = matriculeProf;
        this.nomProf = nomProf;
        this.prenomProf = prenomProf;
        this.groupeProf = groupeProf;
        this.naissanceProf = naissanceProf;
        this.telephoneProf = telephoneProf;
        this.adresseProf = adresseProf;
        this.emailProf = emailProf;
       
    }


    public int getMatriculeProf() {
        return matriculeProf;
    }

    public void setMatriculeProf(int matriculeProf) {
        this.matriculeProf = matriculeProf;
    }

    public String getNomProf() {
        return nomProf;
    }

    public void setNomProf(String nomProf) {
        this.nomProf = nomProf;
    }

    public String getPrenomProf() {
        return prenomProf;
    }

    public void setPrenomProf(String prenomProf) {
        this.prenomProf = prenomProf;
    }

    public String getGroupeProf() {
        return groupeProf;
    }

    public void setGroupeProf(String groupeProf) {
        this.groupeProf = groupeProf;
    }

    public String getNaissanceProf() {
        return naissanceProf;
    }

    public void setNaissanceProf(String naissanceProf) {
        this.naissanceProf = naissanceProf;
    }

    public String getTelephoneProf() {
        return telephoneProf;
    }

    public void setTelephoneProf(String telephoneProf) {
        this.telephoneProf = telephoneProf;
    }

    public String getAdresseProf() {
        return adresseProf;
    }

    public void setAdresseProf(String adresseProf) {
        this.adresseProf = adresseProf;
    }

    public String getEmailProf() {
        return emailProf;
    }

    public void setEmailProf(String emailProf) {
        this.emailProf = emailProf;
    }

   
    
   
}
